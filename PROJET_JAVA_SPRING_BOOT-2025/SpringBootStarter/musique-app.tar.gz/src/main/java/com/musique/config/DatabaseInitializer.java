package com.musique.config;

import com.musique.model.Equipment;
import com.musique.model.User;
import com.musique.repository.EquipmentRepository;
import com.musique.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * Initializes the database with sample data when the application starts.
 */
@Component
public class DatabaseInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private EquipmentRepository equipmentRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Only initialize if the database is empty
        if (userRepository.count() == 0) {
            initializeUsers();
        }
        
        if (equipmentRepository.count() == 0) {
            initializeEquipment();
        }
    }
    
    private void initializeUsers() {
        // Create admin user
        User admin = new User();
        admin.setName("Admin User");
        admin.setEmail("admin@musique.com");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRole("ROLE_ADMIN");
        
        // Create regular user
        User customer = new User();
        customer.setName("John Smith");
        customer.setEmail("john@example.com");
        customer.setPassword(passwordEncoder.encode("password123"));
        customer.setRole("ROLE_USER");
        
        userRepository.saveAll(Arrays.asList(admin, customer));
        
        System.out.println("Sample users created successfully.");
    }
    
    private void initializeEquipment() {
        List<Equipment> equipmentList = Arrays.asList(
            createEquipment("Fender Stratocaster", "Professional electric guitar with legendary tone and playability", new BigDecimal("999.99"), new BigDecimal("49.99"), "GUITAR", 5, "/img/guitar.svg"),
            createEquipment("Gibson Les Paul", "Classic electric guitar with rich, warm tone", new BigDecimal("1299.99"), new BigDecimal("59.99"), "GUITAR", 3, "/img/guitar.svg"),
            createEquipment("Yamaha P-125 Digital Piano", "Compact digital piano with 88 weighted keys", new BigDecimal("699.99"), new BigDecimal("39.99"), "KEYBOARD", 8, "/img/keyboard.svg"),
            createEquipment("Pearl Export Drum Set", "Complete 5-piece drum kit with hardware", new BigDecimal("799.99"), new BigDecimal("69.99"), "DRUMS", 4, "/img/drums.svg"),
            createEquipment("Shure SM58 Microphone", "Industry-standard dynamic vocal microphone", new BigDecimal("99.99"), new BigDecimal("9.99"), "MICROPHONE", 20, "/img/microphone.svg"),
            createEquipment("Ibanez RG550", "High-performance electric guitar for fast players", new BigDecimal("899.99"), new BigDecimal("45.99"), "GUITAR", 7, "/img/guitar.svg"),
            createEquipment("Roland TD-17KVX Electronic Drum Kit", "Professional electronic drum kit with mesh heads", new BigDecimal("1599.99"), new BigDecimal("79.99"), "DRUMS", 3, "/img/drums.svg"),
            createEquipment("Korg Minilogue Synthesizer", "Polyphonic analog synthesizer with versatile sound", new BigDecimal("549.99"), new BigDecimal("29.99"), "KEYBOARD", 6, "/img/keyboard.svg"),
            createEquipment("Martin D-28 Acoustic Guitar", "Premium acoustic guitar with rich tone", new BigDecimal("2799.99"), new BigDecimal("89.99"), "GUITAR", 2, "/img/guitar.svg"),
            createEquipment("Fender Jazz Bass", "Classic electric bass with versatile sound", new BigDecimal("1199.99"), new BigDecimal("59.99"), "BASS", 4, "/img/guitar.svg"),
            createEquipment("Audio-Technica AT2020 Condenser Microphone", "Studio condenser microphone for recording", new BigDecimal("149.99"), new BigDecimal("12.99"), "MICROPHONE", 15, "/img/microphone.svg"),
            createEquipment("Akai MPC Live", "Standalone music production center", new BigDecimal("1199.99"), new BigDecimal("69.99"), "PRODUCTION", 5, "/img/keyboard.svg")
        );
        
        equipmentRepository.saveAll(equipmentList);
        
        System.out.println("Sample equipment created successfully.");
    }
    
    private Equipment createEquipment(String name, String description, BigDecimal priceSale, BigDecimal priceRental, String category, int quantity) {
        Equipment equipment = new Equipment();
        equipment.setName(name);
        equipment.setDescription(description);
        equipment.setPriceSale(priceSale);
        equipment.setPriceRental(priceRental);
        equipment.setCategory(category);
        equipment.setQuantityAvailable(quantity);
        equipment.setActive(true);
        return equipment;
    }
    
    private Equipment createEquipment(String name, String description, BigDecimal priceSale, BigDecimal priceRental, String category, int quantity, String imageUrl) {
        Equipment equipment = createEquipment(name, description, priceSale, priceRental, category, quantity);
        equipment.setImageUrl(imageUrl);
        return equipment;
    }
}