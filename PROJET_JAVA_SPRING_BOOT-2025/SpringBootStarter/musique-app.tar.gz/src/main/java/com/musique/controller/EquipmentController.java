package com.musique.controller;

import com.musique.model.Equipment;
import com.musique.repository.EquipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Controller handling equipment-related requests.
 */
@Controller
@RequestMapping("/equipment")
public class EquipmentController {

    @Autowired
    private EquipmentRepository equipmentRepository;

    /**
     * Display a list of equipment.
     *
     * @param model The model to add attributes to
     * @param page The page number (0-based)
     * @param size The page size
     * @param rental Filter for rental items
     * @param category Filter by category
     * @return The view name
     */
    @GetMapping
    public String listEquipment(
            Model model,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Boolean rental,
            @RequestParam(required = false) String category) {

        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
            Page<Equipment> equipmentPage;
            
            // Apply filters if provided
            if (rental != null && rental) {
                // Filter for items available for rental
                equipmentPage = equipmentRepository.findByPriceRentalGreaterThanAndActiveTrue(
                        java.math.BigDecimal.ZERO, pageable);
                model.addAttribute("rentalMode", true);
            } else if (category != null && !category.isEmpty()) {
                // Filter by category
                equipmentPage = equipmentRepository.findByCategoryAndActiveTrue(category, pageable);
                model.addAttribute("categoryFilter", category);
            } else {
                // No filters, show all active equipment
                equipmentPage = equipmentRepository.findByActiveTrue(pageable);
            }
    
            model.addAttribute("equipment", equipmentPage.getContent());
            model.addAttribute("currentPage", page);
            model.addAttribute("totalPages", equipmentPage.getTotalPages());
            model.addAttribute("totalItems", equipmentPage.getTotalElements());
            
            // Get all unique categories for the filter dropdown
            List<String> categories = equipmentRepository.findDistinctCategories();
            model.addAttribute("categories", categories);
        } catch (Exception e) {
            // En cas d'erreur, initialiser avec des listes vides
            model.addAttribute("equipment", new ArrayList<Equipment>());
            model.addAttribute("currentPage", 0);
            model.addAttribute("totalPages", 0);
            model.addAttribute("totalItems", 0);
            model.addAttribute("categories", new ArrayList<String>());
        }

        return "equipment";
    }

    /**
     * Display details for a specific equipment item.
     *
     * @param id The equipment ID
     * @param model The model to add attributes to
     * @return The view name
     */
    @GetMapping("/{id}")
    public String equipmentDetails(@PathVariable Long id, Model model) {
        try {
            Optional<Equipment> equipment = equipmentRepository.findById(id);
            
            if (equipment.isPresent()) {
                model.addAttribute("equipment", equipment.get());
                // Get related equipment in the same category
                List<Equipment> relatedEquipment = equipmentRepository
                        .findByCategoryAndIdNotAndActiveTrue(
                                equipment.get().getCategory(), 
                                id, 
                                PageRequest.of(0, 4)
                        );
                model.addAttribute("relatedEquipment", relatedEquipment);
                return "equipment-detail";
            } else {
                model.addAttribute("errorMessage", "Equipment not found with ID: " + id);
                return "redirect:/equipment";
            }
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error loading equipment details: " + e.getMessage());
            return "redirect:/equipment";
        }
    }
    
    /**
     * Display a list of recently added equipment.
     *
     * @param model The model to add attributes to
     * @return The view name
     */
    /**
     * Page des équipements récents - modifiée pour éviter le problème 404
     */
    @GetMapping("/recent")
    public String recentEquipment(Model model) {
        try {
            // Get the most recently added equipment (limited to 8)
            Pageable pageable = PageRequest.of(0, 8, Sort.by("id").descending());
            Page<Equipment> recentEquipmentPage = equipmentRepository.findByActiveTrue(pageable);
            
            model.addAttribute("equipment", recentEquipmentPage.getContent());
            model.addAttribute("title", "Équipements récemment ajoutés");
            model.addAttribute("isRecentView", true);
            
            // Get all unique categories for the filter dropdown
            List<String> categories = equipmentRepository.findDistinctCategories();
            model.addAttribute("categories", categories);

            // Log pour le débogage
            System.out.println(">>> Page RECENT - Nombre d'équipements chargés : " + recentEquipmentPage.getContent().size());
        } catch (Exception e) {
            // En cas d'erreur, initialiser avec des listes vides
            model.addAttribute("equipment", new ArrayList<Equipment>());
            model.addAttribute("title", "Équipements récemment ajoutés");
            model.addAttribute("categories", new ArrayList<String>());
            // Log pour le débogage
            System.out.println(">>> ERREUR Page RECENT : " + e.getMessage());
            e.printStackTrace();
        }
        
        return "equipment";
    }
    
    /**
     * Une route alternative pour les équipements récents, au cas où l'URL principale ne fonctionne pas
     */
    @GetMapping("/latest")
    public String latestEquipment(Model model) {
        return recentEquipment(model);
    }
}