package com.musique.service;

import com.musique.model.Equipment;
import com.musique.repository.EquipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service for equipment-related operations.
 */
@Service
public class EquipmentService {

    private final EquipmentRepository equipmentRepository;

    @Autowired
    public EquipmentService(EquipmentRepository equipmentRepository) {
        this.equipmentRepository = equipmentRepository;
    }

    /**
     * Find all equipment
     */
    public List<Equipment> findAll() {
        return equipmentRepository.findAll();
    }

    /**
     * Find equipment by ID
     */
    public Optional<Equipment> findById(Long id) {
        return equipmentRepository.findById(id);
    }

    /**
     * Find equipment by name search
     */
    public List<Equipment> findByNameContaining(String name) {
        return equipmentRepository.findByNameContainingIgnoreCase(name);
    }

    /**
     * Find equipment available for rental
     */
    public List<Equipment> findRentableEquipment() {
        return equipmentRepository.findRentableEquipment();
    }

    /**
     * Find equipment with available stock
     */
    public List<Equipment> findAvailableEquipment() {
        return equipmentRepository.findByQuantityAvailableGreaterThan(0);
    }

    /**
     * Save equipment
     */
    @Transactional
    public Equipment save(Equipment equipment) {
        return equipmentRepository.save(equipment);
    }

    /**
     * Delete equipment by ID
     */
    @Transactional
    public void deleteById(Long id) {
        equipmentRepository.deleteById(id);
    }

    /**
     * Count total equipment
     */
    public long count() {
        return equipmentRepository.count();
    }

    /**
     * Update equipment stock after purchase or rental
     */
    @Transactional
    public void updateStock(Long equipmentId, int quantity) {
        Equipment equipment = equipmentRepository.findById(equipmentId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid equipment ID: " + equipmentId));
        
        int newQuantity = equipment.getQuantityAvailable() - quantity;
        if (newQuantity < 0) {
            throw new IllegalStateException("Not enough stock available for equipment: " + equipment.getName());
        }
        
        equipment.setQuantityAvailable(newQuantity);
        equipmentRepository.save(equipment);
    }
}
