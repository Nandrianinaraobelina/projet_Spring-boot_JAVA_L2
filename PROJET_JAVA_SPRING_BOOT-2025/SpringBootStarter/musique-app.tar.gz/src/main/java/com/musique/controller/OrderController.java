package com.musique.controller;

import com.musique.model.Order;
import com.musique.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

/**
 * Controller for managing orders and order history
 */
@Controller
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderRepository orderRepository;

    /**
     * Display order confirmation page
     * 
     * @param id Order ID
     * @param printMode Set to true for print-friendly version
     * @param model The model
     * @return Order confirmation view
     */
    @GetMapping("/{id}/confirmation")
    public String showConfirmation(@PathVariable Long id, 
                                  @org.springframework.web.bind.annotation.RequestParam(required = false) Boolean print,
                                  Model model) {
        Optional<Order> orderOpt = orderRepository.findById(id);
        
        if (!orderOpt.isPresent()) {
            return "redirect:/";
        }
        
        model.addAttribute("order", orderOpt.get());
        model.addAttribute("printMode", print != null && print);
        return "order-confirmation";
    }
    
    /**
     * List all orders for the current user
     */
    @GetMapping
    public String listOrders(Model model) {
        // Get the authenticated user
        org.springframework.security.core.Authentication auth = 
            org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        
        if (auth == null || auth.getName().equals("anonymousUser")) {
            return "redirect:/login";
        }
        
        // Get orders for this user
        Iterable<Order> orders = orderRepository.findByUserEmailOrderByOrderDateDesc(auth.getName());
        model.addAttribute("orders", orders);
        
        return "orders";
    }
}