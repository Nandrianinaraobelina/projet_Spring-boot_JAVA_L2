package com.musique.controller;

import com.musique.model.Order;
import com.musique.model.OrderItem;
import com.musique.model.User;
import com.musique.repository.OrderRepository;
import com.musique.repository.UserRepository;
import com.musique.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
//import java.time.LocalDateTime; // Removed to fix type incompatibility
import java.util.List;
import java.util.Optional;

/**
 * Controller for handling checkout and payment process
 */
@Controller
@RequestMapping("/checkout")
public class CheckoutController {

    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Show checkout page
     */
    @GetMapping
    public String showCheckout(Model model, HttpSession session) {
        // Check if user is logged in
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName().equals("anonymousUser")) {
            return "redirect:/login?checkout";
        }
        
        // Check if cart is empty
        @SuppressWarnings("unchecked")
        List<OrderItem> cart = (List<OrderItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            return "redirect:/cart";
        }
        
        // Calculate total
        BigDecimal total = cart.stream()
                .map(item -> {
                    if (item.getPrice() != null && item.getQuantity() != null) {
                        return item.getPrice().multiply(new BigDecimal(item.getQuantity()));
                    }
                    return BigDecimal.ZERO;
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Add data to model
        model.addAttribute("cartItems", cart);
        model.addAttribute("total", total);
        
        // Get user information
        Optional<User> user = userRepository.findByEmail(auth.getName());
        user.ifPresent(u -> model.addAttribute("user", u));
        
        return "checkout";
    }
    
    /**
     * Process checkout (payment and order creation)
     */
    @PostMapping
    public String processCheckout(HttpSession session, RedirectAttributes redirectAttributes) {
        // Check if user is logged in
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName().equals("anonymousUser")) {
            return "redirect:/login?checkout";
        }
        
        // Check if cart is empty
        @SuppressWarnings("unchecked")
        List<OrderItem> cart = (List<OrderItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            return "redirect:/cart";
        }
        
        // Get user
        Optional<User> userOpt = userRepository.findByEmail(auth.getName());
        if (!userOpt.isPresent()) {
            redirectAttributes.addFlashAttribute("errorMessage", "User account not found.");
            return "redirect:/cart";
        }
        
        User user = userOpt.get();
        
        try {
            // Create order
            Order order = new Order();
            order.setUser(user);
            order.setOrderDate(new java.util.Date());
            
            // Calculate total
            BigDecimal total = cart.stream()
                    .map(item -> {
                        if (item.getPrice() != null && item.getQuantity() != null) {
                            return item.getPrice().multiply(new BigDecimal(item.getQuantity()));
                        }
                        return BigDecimal.ZERO;
                    })
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            order.setTotalAmount(total);
            order.setStatus("PAID");
            order.setOrderType("SALE"); // Default to sale type
            
            // Save order
            Order savedOrder = orderRepository.save(order);
            
            // Update order items with the order reference and save them
            for (OrderItem item : cart) {
                item.setOrder(savedOrder);
                // No need to save items separately if cascade is properly set up
            }
            
            // Clear cart after successful checkout
            session.removeAttribute("cart");
            
            // Add success message
            redirectAttributes.addFlashAttribute("successMessage", 
                    "Your order has been placed successfully! Order number: " + savedOrder.getId());
            
            return "redirect:/orders/confirmation/" + savedOrder.getId();
            
        } catch (Exception e) {
            // Log the error
            System.err.println("Error processing checkout: " + e.getMessage());
            
            // Add error message
            redirectAttributes.addFlashAttribute("errorMessage", 
                    "There was a problem processing your order. Please try again.");
            
            return "redirect:/cart";
        }
    }
}